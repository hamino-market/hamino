const products=[
["یخچال فریزر نو","🏠","۳۲,۵۰۰,۰۰۰ تومان"],
["چای‌ساز برقی","🍵","۲,۸۵۰,۰۰۰ تومان"],
["تلویزیون هوشمند","📺","۱۸,۹۰۰,۰۰۰ تومان"],
["جاروبرقی","🧹","۷,۴۰۰,۰۰۰ تومان"],
["مایکروویو","🍽️","۹,۸۰۰,۰۰۰ تومان"],
["دریل برقی","🔧","۳,۲۰۰,۰۰۰ تومان"],
["ماشین لباسشویی","🧺","۲۶,۷۰۰,۰۰۰ تومان"],
["پنکه برقی","🌀","۴,۶۰۰,۰۰۰ تومان"]
];
const grid=document.getElementById("productGrid");
products.forEach((p,i)=>{
 const el=document.createElement("article"); el.className="product";
 el.innerHTML=`<div class="pic">${p[1]}</div><h3>${p[0]}</h3><div class="price">${p[2]}</div><button onclick="addCart()">افزودن به سبد</button>`;
 grid.appendChild(el);
});
let count=0;
function addCart(){count++;document.getElementById("cartCount").textContent=count.toLocaleString("fa-IR");}
document.getElementById("search").addEventListener("input",e=>{
 const q=e.target.value.trim();
 [...document.querySelectorAll(".product")].forEach((el)=>el.style.display=(!q||el.innerText.includes(q))?"block":"none");
});
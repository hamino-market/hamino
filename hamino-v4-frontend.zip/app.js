/* HAMINO v3 - Seller System + Orders */
// بعد از استقرار Backend، آدرس آن را اینجا قرار دهید.
// مثال: https://your-hamino-backend.example.com
const API_BASE_URL = localStorage.getItem("hamino_api_url") || "";
const products=[
 ["یخچال فریزر نو","🏠","۳۲,۵۰۰,۰۰۰ تومان",32500000,"همینو"],
 ["چای‌ساز برقی","🍵","۲,۸۵۰,۰۰۰ تومان",2850000,"همینو"],
 ["تلویزیون هوشمند","📺","۱۸,۹۰۰,۰۰۰ تومان",18900000,"همینو"],
 ["جاروبرقی","🧹","۷,۴۰۰,۰۰۰ تومان",7400000,"همینو"],
 ["مایکروویو","🍽️","۹,۸۰۰,۰۰۰ تومان",9800000,"همینو"],
 ["دریل برقی","🔧","۳,۲۰۰,۰۰۰ تومان",3200000,"همینو"],
 ["ماشین لباسشویی","🧺","۲۶,۷۰۰,۰۰۰ تومان",26700000,"همینو"],
 ["پنکه برقی","🌀","۴,۶۰۰,۰۰۰ تومان",4600000,"همینو"]
];
let cart=[];
function faNumber(n){return Number(n||0).toLocaleString("fa-IR");}
function formatPrice(n){return faNumber(n)+" تومان";}
function makeId(prefix="HM"){return prefix+"-"+Date.now().toString().slice(-8)+"-"+Math.floor(100+Math.random()*900);}
function getSeller(){try{return JSON.parse(localStorage.getItem("hamino_seller")||"null");}catch{return null;}}
function saveSeller(s){localStorage.setItem("hamino_seller",JSON.stringify(s));}
function getSellerProducts(){try{return JSON.parse(localStorage.getItem("hamino_seller_products")||"[]");}catch{return [];}}
function saveSellerProducts(p){localStorage.setItem("hamino_seller_products",JSON.stringify(p));}
function getOrders(){try{return JSON.parse(localStorage.getItem("hamino_orders")||"[]");}catch{return [];}}
function saveOrders(o){localStorage.setItem("hamino_orders",JSON.stringify(o));}
function allProducts(){return products.concat(getSellerProducts().map(p=>[p.name,p.icon||"📦",formatPrice(p.price),Number(p.price),p.sellerName||"فروشنده"]));}
function renderProducts(){const grid=document.getElementById("productGrid");if(!grid)return;const list=allProducts();grid.innerHTML=list.map((p,i)=>`<article class="product"><div class="pic">${p[1]}</div><h3>${p[0]}</h3><div class="price">${p[2]}</div><small class="seller-name">فروشنده: ${p[4]}</small><button onclick="addCart(${i})">افزودن به سبد</button></article>`).join("");}
function addCart(index){cart.find(i=>i.index===index)?cart.find(i=>i.index===index).qty++:cart.push({index,qty:1});updateCart();openCart();}
function changeQty(index,a){const x=cart.find(i=>i.index===index);if(!x)return;x.qty+=a;if(x.qty<=0)cart=cart.filter(i=>i.index!==index);updateCart();}
function removeCart(index){cart=cart.filter(i=>i.index!==index);updateCart();}
function cartList(){return allProducts();}
function cartTotal(){const ps=cartList();return cart.reduce((s,i)=>s+(ps[i.index][3]*i.qty),0);}
function updateCart(){document.getElementById("cartCount").textContent=faNumber(cart.reduce((s,i)=>s+i.qty,0));document.getElementById("cartTotal").textContent=formatPrice(cartTotal());const b=document.getElementById("cartItems");if(!cart.length){b.innerHTML='<div class="empty-cart">🛒<br><br>سبد خرید شما خالی است.</div>';return;}const ps=cartList();b.innerHTML=cart.map(i=>{const p=ps[i.index];return `<div class="cart-item"><div class="cart-item-pic">${p[1]}</div><div class="cart-item-info"><h3>${p[0]}</h3><div class="cart-item-price">${formatPrice(p[3])}</div><div class="qty"><button onclick="changeQty(${i.index},1)">+</button><strong>${faNumber(i.qty)}</strong><button onclick="changeQty(${i.index},-1)">−</button><button class="remove" onclick="removeCart(${i.index})">حذف</button></div></div></div>`}).join("");}
function openCart(){document.getElementById("cartOverlay").classList.add("open");updateCart();}
function closeCart(e){if(e&&e.target!==document.getElementById("cartOverlay"))return;document.getElementById("cartOverlay").classList.remove("open");}
function checkout(){if(!cart.length){alert("سبد خرید شما خالی است.");return;}document.getElementById("checkoutSummary").textContent=faNumber(cart.reduce((s,i)=>s+i.qty,0))+" کالا — "+formatPrice(cartTotal());document.getElementById("orderSubtotal").textContent=formatPrice(cartTotal());updateShippingCost();document.getElementById("cartOverlay").classList.remove("open");document.getElementById("checkoutOverlay").classList.add("open");}
function updateShippingCost(){const c=document.getElementById("shippingMethod").value==="express"?150000:0;document.getElementById("shippingCost").textContent=c?formatPrice(c):"رایگان";document.getElementById("orderTotal").textContent=formatPrice(cartTotal()+c);}
function closeCheckout(e){if(e&&e.target!==document.getElementById("checkoutOverlay"))return;document.getElementById("checkoutOverlay").classList.remove("open");}
async function apiRequest(path, options={}){
  const url=(API_BASE_URL||"").replace(/\/$/,"")+path;
  const res=await fetch(url,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  let data=null;
  try{data=await res.json();}catch{}
  if(!res.ok) throw new Error(data?.error||"خطا در ارتباط با سرور");
  return data;
}

async function saveOrderToServer(order){
  if(!API_BASE_URL) return null;
  return await apiRequest("/api/orders",{
    method:"POST",
    body:JSON.stringify(order)
  });
}

async function loadOrdersFromServer(){
  if(!API_BASE_URL) return null;
  const data=await apiRequest("/api/orders");
  return Array.isArray(data.orders)?data.orders.map(serverOrderToClient):[];
}

function serverOrderToClient(x){
  return {
    id:x.id,
    number:x.number,
    status:x.status,
    paymentStatus:x.payment_status,
    customer:{
      name:x.customer_name, phone:x.customer_phone,
      province:x.customer_province, city:x.customer_city,
      address:x.customer_address, postal:x.customer_postal
    },
    shipping:{method:x.shipping_method,cost:Number(x.shipping_cost||0)},
    items:typeof x.items==="string"?JSON.parse(x.items):x.items,
    totals:{
      subtotal:Number(x.subtotal||0),
      shipping:Number(x.shipping_cost||0),
      total:Number(x.total||0)
    },
    createdAt:x.created_at,
    updatedAt:x.updated_at
  };
}

async function syncAdminOrders(){
  if(!API_BASE_URL) return;
  try{
    const orders=await loadOrdersFromServer();
    saveOrders(orders);
    renderOrders();
  }catch(err){
    console.warn("HAMINO server sync:",err.message);
  }
}

async function submitOrder(e){e.preventDefault();const phone=document.getElementById("customerPhone").value.trim(),postal=document.getElementById("customerPostal").value.trim();if(!/^09\d{9}$/.test(phone)){alert("شماره موبایل باید ۱۱ رقمی و با 09 شروع شود.");return;}if(!/^\d{10}$/.test(postal)){alert("کد پستی باید ۱۰ رقمی باشد.");return;}const shipping=document.getElementById("shippingMethod").value,sc=shipping==="express"?150000:0,ps=cartList();const order={id:makeId(),number:makeId("HM"),status:"new",paymentStatus:"unpaid",customer:{name:customerName.value.trim(),phone,province:customerProvince.value.trim(),city:customerCity.value.trim(),address:customerAddress.value.trim(),postal},shipping:{method:shipping,cost:sc},items:cart.map(i=>{const p=ps[i.index];return {name:p[0],price:p[3],qty:i.qty,sellerName:p[4]};}),totals:{subtotal:cartTotal(),shipping:sc,total:cartTotal()+sc},createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};const orders=getOrders();orders.unshift(order);saveOrders(orders);localStorage.setItem("hamino_last_order",JSON.stringify(order));
try{
  if(API_BASE_URL){
    await saveOrderToServer(order);
    const fresh=await loadOrdersFromServer();
    saveOrders(fresh);
  }
}catch(err){
  console.warn("ثبت روی سرور انجام نشد:",err.message);
  alert("سفارش روی دستگاه ذخیره شد، اما اتصال به سرور برقرار نشد. بعداً دوباره همگام‌سازی می‌کنیم.");
}
document.getElementById("checkoutFormWrap").style.display="none";document.getElementById("orderSuccess").style.display="block";document.getElementById("orderNumber").textContent=order.number;}
function finishOrder(){cart=[];updateCart();document.getElementById("checkoutForm").reset();document.getElementById("checkoutFormWrap").style.display="block";document.getElementById("orderSuccess").style.display="none";document.getElementById("checkoutOverlay").classList.remove("open");}
function orderStatusText(s){return ({new:"جدید",processing:"در حال پردازش",shipped:"ارسال شده",delivered:"تحویل شده",cancelled:"لغو شده"})[s]||"جدید";}
function openAdmin(){
  document.getElementById("adminOverlay").classList.add("open");
  renderOrders();
  syncAdminOrders();
}
function closeAdmin(e){if(e&&e.target!==document.getElementById("adminOverlay"))return;document.getElementById("adminOverlay").classList.remove("open");}
function renderOrders(){const o=getOrders(),b=document.getElementById("adminOrders");document.getElementById("adminOrderCount").textContent=faNumber(o.length);if(!o.length){b.innerHTML='<div class="admin-empty">📦<br><br>هنوز سفارشی ثبت نشده است.</div>';return;}b.innerHTML=o.map((x,i)=>`<div class="admin-order"><div class="admin-order-head"><div><strong>${x.number}</strong><small>${new Date(x.createdAt).toLocaleString("fa-IR")}</small></div><select onchange="changeOrderStatus(${i},this.value)">${["new","processing","shipped","delivered","cancelled"].map(s=>`<option value="${s}" ${x.status===s?"selected":""}>${orderStatusText(s)}</option>`).join("")}</select></div><div class="admin-badges"><span>${orderStatusText(x.status)}</span><span>${x.paymentStatus==="paid"?"پرداخت شده":"پرداخت نشده"}</span></div><div class="admin-customer"><strong>${x.customer.name}</strong><span>📱 ${x.customer.phone}</span><span>📍 ${x.customer.province}، ${x.customer.city}</span><span>🏠 ${x.customer.address}</span></div><div class="admin-items">${x.items.map(z=>`<div><span>${z.name} × ${faNumber(z.qty)}</span><strong>${formatPrice(z.price*z.qty)}</strong></div>`).join("")}</div><div class="admin-total">مبلغ سفارش: <strong>${formatPrice(x.totals.total)}</strong></div><button class="admin-pay" onclick="markPaid(${i})">علامت پرداخت‌شده</button><button class="admin-delete" onclick="deleteOrder(${i})">حذف سفارش آزمایشی</button></div>`).join("");}
async function changeOrderStatus(i,s){
  const o=getOrders();if(!o[i])return;
  const old=o[i].status;
  o[i].status=s;o[i].updatedAt=new Date().toISOString();saveOrders(o);renderOrders();
  if(API_BASE_URL){
    try{await apiRequest("/api/orders/"+encodeURIComponent(o[i].id)+"/status",{method:"PATCH",body:JSON.stringify({status:s})});}
    catch(err){o[i].status=old;saveOrders(o);renderOrders();alert("تغییر وضعیت روی سرور انجام نشد.");}
  }
}
async function markPaid(i){
  const o=getOrders();if(!o[i])return;
  o[i].paymentStatus="paid";o[i].updatedAt=new Date().toISOString();saveOrders(o);renderOrders();
  if(API_BASE_URL){
    try{await apiRequest("/api/orders/"+encodeURIComponent(o[i].id)+"/payment",{method:"PATCH",body:JSON.stringify({paymentStatus:"paid"})});}
    catch(err){alert("وضعیت پرداخت روی سرور ثبت نشد.");}
  }
}
async function deleteOrder(i){
  if(!confirm("این سفارش حذف شود؟"))return;
  const o=getOrders();const target=o[i];o.splice(i,1);saveOrders(o);renderOrders();
  if(API_BASE_URL){
    try{await apiRequest("/api/orders/"+encodeURIComponent(target.id),{method:"DELETE"});}
    catch(err){alert("حذف از سرور انجام نشد؛ فهرست دوباره از سرور خوانده می‌شود.");syncAdminOrders();}
  }
}
function openSeller(){document.getElementById("sellerOverlay").classList.add("open");renderSellerPanel();}
function closeSeller(e){if(e&&e.target!==document.getElementById("sellerOverlay"))return;document.getElementById("sellerOverlay").classList.remove("open");}
function renderSellerPanel(){const s=getSeller();document.getElementById("sellerLoggedOut").style.display=s?"none":"block";document.getElementById("sellerLoggedIn").style.display=s?"block":"none";if(!s)return;document.getElementById("sellerWelcome").textContent="سلام، "+s.name;document.getElementById("sellerPhoneView").textContent=s.phone;const ps=getSellerProducts();document.getElementById("sellerProductCount").textContent=faNumber(ps.length);document.getElementById("sellerProductList").innerHTML=ps.length?ps.map((p,i)=>`<div class="seller-product"><span>${p.icon||"📦"} ${p.name}</span><strong>${formatPrice(p.price)}</strong><button onclick="deleteSellerProduct(${i})">حذف</button></div>`).join(""):"<p>هنوز محصولی ثبت نکرده‌اید.</p>";}
function registerSeller(e){e.preventDefault();const name=sellerName.value.trim(),phone=sellerPhone.value.trim();if(name.length<2||!/^09\d{9}$/.test(phone)){alert("نام و شماره موبایل معتبر وارد کنید.");return;}saveSeller({id:makeId("SEL"),name,phone,createdAt:new Date().toISOString()});e.target.reset();renderSellerPanel();}
function addSellerProduct(e){e.preventDefault();const s=getSeller();if(!s){alert("ابتدا به عنوان فروشنده ثبت‌نام کنید.");return;}const name=productName.value.trim(),price=Number(productPrice.value);if(!name||!price||price<1000){alert("نام محصول و قیمت معتبر وارد کنید.");return;}const list=getSellerProducts();list.unshift({id:makeId("PRD"),name,price,icon:productIcon.value.trim()||"📦",sellerId:s.id,sellerName:s.name,createdAt:new Date().toISOString()});saveSellerProducts(list);e.target.reset();renderProducts();renderSellerPanel();alert("محصول با موفقیت به فروشگاه اضافه شد.");}
function deleteSellerProduct(i){const p=getSellerProducts();p.splice(i,1);saveSellerProducts(p);renderProducts();renderSellerPanel();}
function sellerLogout(){localStorage.removeItem("hamino_seller");renderSellerPanel();}
document.addEventListener("DOMContentLoaded",()=>{renderProducts();updateCart();document.getElementById("search").addEventListener("input",e=>{const q=e.target.value.trim();document.querySelectorAll(".product").forEach(el=>el.style.display=(!q||el.innerText.includes(q))?"block":"none")});document.getElementById("shippingMethod").addEventListener("change",updateShippingCost);renderSellerPanel();syncAdminOrders();});

HAMINO V4 - Frontend connected to Backend API

این نسخه app.js به API سفارش‌ها متصل شده است.
تا زمانی که API_BASE_URL خالی باشد، localStorage استفاده می‌شود.
بعد از استقرار Backend:
localStorage.setItem("hamino_api_url","https://YOUR-BACKEND-URL")
یا مقدار API_BASE_URL را در app.js تنظیم کنید.

APIهای مورد استفاده:
POST /api/orders
GET /api/orders
PATCH /api/orders/:id/status
PATCH /api/orders/:id/payment
DELETE /api/orders/:id
